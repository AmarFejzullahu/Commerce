# Commerce Lakehouse Pipeline

## Overview

This project builds a reproducible Databricks Lakehouse pipeline from five independent Commerce source exports:

- `customers_raw.csv`
- `products_raw.csv`
- `orders_raw.csv`
- `order_items_raw.csv`
- `payments_raw.csv`

The implementation follows a Bronze / Silver / Gold architecture and keeps rejected records traceable instead of silently dropping them.

The notebook style intentionally follows the earlier E-Commerce project: straightforward PySpark DataFrame transformations, explicit intermediate DataFrames, `print()` summaries, `display()` checks and simple validation logic.

## Required Architecture

### Bronze

Bronze is the raw-preservation layer.

The source files are loaded with explicit Spark schemas. `order_date` and `payment_date` are intentionally read as strings in Bronze. They are parsed and validated only in Silver.

Bronze adds only traceability metadata:

- `_source_name`
- `_source_file`
- `_ingested_at`
- `_source_row_hash`

The raw CSV files are never edited.

Persistent Bronze Delta tables:

- `workspace.commerce_dataset.bronze_customers`
- `workspace.commerce_dataset.bronze_products`
- `workspace.commerce_dataset.bronze_orders`
- `workspace.commerce_dataset.bronze_order_items`
- `workspace.commerce_dataset.bronze_payments`

### Silver

Silver contains typed, standardized, deduplicated and relationship-validated business entities.

Persistent Silver Delta tables:

- `workspace.commerce_dataset.silver_customers`
- `workspace.commerce_dataset.silver_products`
- `workspace.commerce_dataset.silver_orders`
- `workspace.commerce_dataset.silver_order_items`
- `workspace.commerce_dataset.silver_payments`

Rejected records are stored in:

- `workspace.commerce_dataset.quarantine_records`

Each quarantine record contains:

- entity name
- business identifier
- parent order identifier when applicable
- validation reason
- original raw record as JSON
- source metadata

### Gold

Gold contains business-ready outputs for Finance and Analytics.

Persistent Gold Delta tables:

- `workspace.commerce_dataset.gold_finance_reconciliation`
- `workspace.commerce_dataset.gold_trusted_revenue_orders`
- `workspace.commerce_dataset.gold_revenue_by_date_city`
- `workspace.commerce_dataset.gold_revenue_by_product`
- `workspace.commerce_dataset.gold_revenue_by_category`
- `workspace.commerce_dataset.gold_revenue_by_customer`
- `workspace.commerce_dataset.gold_revenue_by_customer_type`
- `workspace.commerce_dataset.gold_reconciliation_summary`
- `workspace.commerce_dataset.gold_reconciliation_investigation`
- `workspace.commerce_dataset.gold_data_quality_summary`

## Execution Order

Run the notebooks in this order:

1. `01_data_exploration`
2. `02_data_cleaning`
3. `03_business_analysis`

Notebook 1 profiles the raw data and persists Bronze.

Notebook 2 reads Bronze, validates and standardizes the five entities, writes trusted Silver tables and writes quarantine records.

Notebook 3 reads the persistent Silver and quarantine tables, builds Finance reconciliation, creates Gold reporting outputs, writes the data-quality summary and runs an `explain()` review.

## Relationships

The pipeline uses these relationships:

`customers.customer_id -> orders.customer_id`

`orders.order_id -> order_items.order_id`

`products.product_id -> order_items.product_id`

`orders.order_id -> payments.order_id`

Relationships are validated against trusted parent datasets rather than assumed to be correct.

An order is not eligible for trusted Silver if its customer is missing from trusted customers.

An order item is not eligible for trusted Silver if its order or product is missing from the corresponding trusted Silver table.

A payment is not eligible for trusted Silver if its order is missing from trusted orders.

## Main Validation Rules

### Customers

`customer_id` is the structural relationship key and must be present and positive.

Missing customer names are changed to `Unknown` because the name is descriptive and does not prevent relationship matching.

Malformed emails are changed to null rather than rejecting the customer because email is not the relationship key for this pipeline.

Customer type and city are standardized for reliable grouping.

### Products

`product_id` must be present and positive.

`product_name` must be present.

`list_price` must be greater than zero.

Category formatting is standardized.

The transaction `unit_price` is not forced to equal `list_price`. A sale price may legitimately differ from the catalog list price.

### Orders

`order_id` and `customer_id` must be present and positive.

`order_date` must parse to a valid date.

Allowed normalized order statuses are:

- `completed`
- `pending`
- `cancelled`
- `refunded`

`canceled` is standardized to `cancelled`.

The customer must exist in trusted Silver customers.

### Order Items

`order_item_id`, `order_id` and `product_id` must be valid identifiers.

`quantity` must be greater than zero.

`unit_price` must be greater than zero.

The referenced order and product must exist in trusted Silver datasets.

`line_total = quantity * unit_price`.

### Payments

Allowed normalized payment statuses are:

- `paid`
- `failed`
- `refunded`

Payment methods are standardized to:

- `Card`
- `Bank Transfer`
- `PayPal`
- `Cash`

Amount rules are:

- `paid` must have amount greater than zero
- `failed` must have amount equal to zero
- `refunded` must have a negative amount

`payment_date` must parse to a valid date.

A payment dated before its referenced order date is quarantined. The provided brief does not state that prepayments are allowed, so a payment occurring before the order exists is treated as a date/relationship anomaly. If the real business explicitly allows prepayment, this rule should be changed rather than silently ignored.

## Duplicate Handling

Exact duplicate source rows are not allowed to inflate trusted datasets.

One identical copy is retained and additional copies are quarantined with:

`exact_duplicate`

If a business identifier still has multiple different records after exact duplicate removal, all conflicting records for that identifier are quarantined with:

`conflicting_business_identifier`

The supplied Commerce files contain exact duplicate identifiers, but no conflicting versions remain after exact duplicate removal.

## Finance Reconciliation

Expected commercial order value is calculated from trusted order items:

`expected_order_value = SUM(quantity * unit_price)`

Trusted payment activity is aggregated by order.

The reconciliation status is assigned in this order:

1. `REFUNDED` - order status is refunded or trusted refund activity exists.
2. `NON_STANDARD` - there is no usable trusted order value, or rejected payment activity exists while no trusted paid amount is available.
3. `MISSING_PAYMENT` - no usable paid amount is available.
4. `MATCHED` - paid amount equals expected order value within a tolerance of 0.01.
5. `UNDERPAID` - paid amount is below expected order value.
6. `OVERPAID` - paid amount is above expected order value.

`reconciliation_difference = paid_amount - expected_order_value`

The Gold investigation table sorts underpaid and overpaid orders by absolute reconciliation difference.

## Trusted Revenue Definition

Trusted revenue is deliberately conservative.

An order contributes trusted revenue only when:

- the order exists in trusted Silver
- trusted order items produce an expected order value
- the normalized order status is `completed`
- reconciliation status is `MATCHED`

For those orders:

`trusted_revenue = expected_order_value`

Pending, cancelled, refunded, underpaid, overpaid, missing-payment and non-standard orders are excluded from trusted revenue.

This means the Gold revenue number is a trusted subset of commercial activity, not a claim that every raw order represents recognized revenue.

## Spark `explain()` and Lazy Evaluation

Notebook 3 calls:

`trusted_product_lines.explain(mode="formatted")`

The pipeline being inspected starts from trusted revenue orders, joins trusted order items, joins trusted products and then feeds product/category revenue aggregations.

Spark transformations such as `filter()`, `join()`, `withColumn()` and `groupBy()` build a logical plan. Spark does not need to execute the full pipeline when those transformations are defined.

Actions such as `count()`, `first()`, `display()` and Delta writes trigger execution.

The formatted `explain()` output lets you inspect Spark's parsed/analyzed/optimized/physical planning before the action executes the full result. The exact join strategy and physical operators can vary with Databricks runtime statistics, so the live output from your run is the authoritative plan.

For this pipeline, expect the plan to include Delta scans, filters, joins and aggregation stages. Aggregations and some joins may require data exchange/shuffle. The important point for this assignment is understanding that the transformations are defined lazily and Spark optimizes the plan before an action triggers execution.

## Trace One Order End to End

Notebook 3 includes a trace for order `600002`.

In the supplied files:

- Bronze preserves the completed order dated `2026-07-15`.
- Its four order items produce an expected order value of `1936.23`.
- The payment amount is also `1936.23`, but its payment date is `2026-04-08`.
- Because the payment predates the order, that payment is quarantined.
- The order and valid items can reach Silver, but the payment does not.
- Gold therefore marks the order as `NON_STANDARD`, and it does not contribute trusted revenue.

This example shows why matching amounts alone are not sufficient for Finance reconciliation.

## Key Observed Data-Quality Results

Based on the supplied Commerce CSV files and the rules above:

- customers: 715 raw -> 700 trusted
- products: 84 raw -> 80 trusted
- orders: 4,555 raw -> 4,409 trusted
- order items: 11,148 raw -> 10,696 trusted
- payments: 4,072 raw -> 2,058 trusted

The payment dataset has the largest quality problem because many payment dates occur before the referenced order date.

See `reports/data_profile.md` and `reports/data_quality_summary.md` for more detail.

## Expected Gold Results From the Supplied Files

With the current business rules, the supplied files produce approximately:

- 1,203 completed matched orders eligible for trusted revenue
- trusted revenue of `$1,549,918.12`
- 1,634 matched orders across all order statuses
- 79 underpaid orders
- 49 overpaid orders
- 470 orders with no usable payment
- 427 refunded orders
- 1,750 non-standard orders

These values are documented for verification only. The notebooks calculate every result from trusted Delta data and do not hardcode final totals.

## Management Interpretation

Finance should not report revenue directly from the raw order or payment exports.

Finance can use the Gold trusted-revenue output as a reproducible trusted subset because it requires valid entities, valid relationships, completed order status and matched trusted payment activity.

However, the high number of payment-date anomalies means the source systems should be investigated. The trusted revenue figure should not be interpreted as total possible Commerce revenue until the upstream payment-date issue is understood.

## Scaling to Hundreds of Millions of Rows

For much larger data volumes, the overall business rules can stay the same, but the execution strategy should change.

Main changes would include:

- incremental ingestion instead of full overwrite from CSV
- Auto Loader or another incremental Bronze ingestion mechanism
- Delta `MERGE` or change-based processing for Silver
- partitioning or liquid clustering based on actual query patterns
- avoiding repeated full-table `count()` actions in production jobs
- using table statistics and appropriate join strategies
- broadcasting genuinely small dimensions such as products when appropriate
- pruning columns early
- compacting small files and maintaining Delta tables
- monitoring data-quality metrics over time
- using job orchestration, checkpoints and alerting

The current notebook is intentionally readable for the assignment rather than prematurely optimized.

## Files

`notebooks/01_data_exploration.ipynb`

`notebooks/02_data_cleaning.ipynb`

`notebooks/03_business_analysis.ipynb`

`reports/architecture_diagram.md`

`reports/data_profile.md`

`reports/data_quality_summary.md`

`reports/management_summary.md`

`reports/handover_answers.md`

`reports/requirements_checklist.md`
