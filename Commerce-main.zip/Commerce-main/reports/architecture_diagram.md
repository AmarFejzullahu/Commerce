# Commerce Lakehouse Architecture Diagram

```mermaid
flowchart LR
    C[customers_raw.csv] --> BC[Bronze Customers]
    P[products_raw.csv] --> BP[Bronze Products]
    O[orders_raw.csv] --> BO[Bronze Orders]
    I[order_items_raw.csv] --> BI[Bronze Order Items]
    PM[payments_raw.csv] --> BPM[Bronze Payments]

    BC --> SC[Silver Customers]
    BP --> SP[Silver Products]
    BO --> SO[Silver Orders]
    BI --> SI[Silver Order Items]
    BPM --> SPM[Silver Payments]

    BC --> Q[Quarantine Records]
    BP --> Q
    BO --> Q
    BI --> Q
    BPM --> Q

    SC --> SO
    SO --> SI
    SP --> SI
    SO --> SPM

    SO --> R[Gold Finance Reconciliation]
    SI --> R
    SPM --> R
    Q --> R

    R --> TR[Gold Trusted Revenue Orders]
    TR --> RDC[Revenue by Date and City]
    TR --> RC[Revenue by Customer / Type]
    TR --> RP[Revenue by Product / Category]
    R --> RS[Reconciliation Summary / Investigation]

    BC --> DQ[Gold Data Quality Summary]
    BP --> DQ
    BO --> DQ
    BI --> DQ
    BPM --> DQ
    Q --> DQ
    SC --> DQ
    SP --> DQ
    SO --> DQ
    SI --> DQ
    SPM --> DQ
```

## Layer Responsibilities

**Bronze** preserves source values with minimal transformation and source traceability metadata.

**Silver** standardizes, deduplicates, validates required values and validates entity relationships.

**Quarantine** preserves every rejected source record with a validation reason.

**Gold** produces Finance reconciliation, trusted revenue and analytics-ready aggregations.
