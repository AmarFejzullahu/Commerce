# Data Profile

## Overview

The supplied Commerce project contains five raw CSV exports:

- `customers_raw.csv`: 715 records
- `products_raw.csv`: 84 records
- `orders_raw.csv`: 4,555 records
- `order_items_raw.csv`: 11,148 records
- `payments_raw.csv`: 4,072 records

The raw files were profiled without editing them.

## Customers

Columns:

`customer_id`, `customer_name`, `email`, `city`, `customer_type`

Observed issues:

- 15 exact duplicate rows beyond the first copy
- 8 missing customer names
- 12 malformed email values (`bad-email`)
- customer type uses inconsistent capitalization such as `retail`, `Retail`, `business`, `BUSINESS`, `vip`
- city values use inconsistent capitalization and spelling variants such as `Prishtina`, `PRISHTINA`, `Gjakove`, `Gjakovë`, `Mitrovice`, `Mitrovicë`

`customer_id` remains the relationship key. Missing names and malformed emails are descriptive-data issues, so the pipeline repairs those values rather than rejecting an otherwise matchable customer.

## Products

Columns:

`product_id`, `product_name`, `category`, `list_price`

Observed issues:

- 4 exact duplicate rows beyond the first copy
- inconsistent category capitalization such as `home`, `Home`, `electronics`, `Electronics`
- no non-positive list prices were found

The transaction `unit_price` is not assumed to equal product `list_price` because transaction pricing may legitimately differ from catalog pricing.

## Orders

Columns:

`order_id`, `customer_id`, `order_date`, `shipping_city`, `order_status`

Observed issues:

- 55 exact duplicate rows beyond the first copy
- 15 invalid dates using the malformed value `2026-99-40`
- 15 orders with unexpected status `unknown`
- 64 raw order rows reference customer IDs that are not present in the customer file; after exact duplicate removal this represents 63 order records
- 44 distinct missing customer identifiers are referenced by raw orders
- status formatting varies across `completed`, `Completed`, `COMPLETED`, `pending`, `Pending`, `PENDING`, `cancelled`, `canceled`, `refunded`, and capitalization/whitespace variants
- shipping-city formatting has the same type of spelling/capitalization inconsistency seen in customers

## Order Items

Columns:

`order_item_id`, `order_id`, `product_id`, `quantity`, `unit_price`

Observed issues:

- 40 exact duplicate rows beyond the first copy
- 92 rows have quantity less than or equal to zero
- 61 rows have unit price less than or equal to zero
- 15 raw rows reference an order ID that does not exist in raw orders
- 25 raw rows reference a product ID that does not exist in raw products

After trusted-parent validation, additional order items become ineligible when their referenced order was quarantined for its own data-quality problem.

## Payments

Columns:

`payment_id`, `order_id`, `amount`, `payment_method`, `payment_status`, `payment_date`

Observed issues:

- 30 exact duplicate rows beyond the first copy
- 13 `paid` records have amount `0`, which is inconsistent with a successful payment
- all `failed` records use amount `0`
- all `refunded` records use a negative amount
- payment methods use inconsistent representations such as `CARD`, `card`, `Bank Transfer`, `bank_transfer`, `paypal`, and `cash`
- payment dates are syntactically valid, but a very large number occur before the date of the referenced order

After exact duplicate removal and trusted-order matching, 1,893 payment rows are dated before their trusted order date. Six of those also violate the amount/status rule. This is the most significant data-quality problem in the supplied files.

## Relationship Findings

The intended relationships are:

`customers.customer_id -> orders.customer_id`

`orders.order_id -> order_items.order_id`

`products.product_id -> order_items.product_id`

`orders.order_id -> payments.order_id`

The raw data demonstrates why these relationships must be validated instead of assumed.

## Conclusion

The raw exports are not safe for direct Finance or Analytics reporting.

The most important risks are exact duplicates, invalid order dates, orphan relationships, invalid order-item values and the large number of payment records that predate their orders.
