# Data Quality Summary

## Final Source-to-Silver Results

Using the validation rules implemented in `02_data_cleaning`:

| Entity | Raw | Rejected / Quarantined | Trusted Silver | Success Rate |
| --- | ---: | ---: | ---: | ---: |
| Customers | 715 | 15 | 700 | 97.90% |
| Products | 84 | 4 | 80 | 95.24% |
| Orders | 4,555 | 146 | 4,409 | 96.79% |
| Order Items | 11,148 | 452 | 10,696 | 95.95% |
| Payments | 4,072 | 2,014 | 2,058 | 50.54% |

Across all five source files, 17,943 of 20,574 records reach trusted Silver datasets, an overall record-level success rate of approximately 87.21%.

The overall percentage is only a simple record-level indicator. Each entity has different business meaning, so the per-entity rates are more useful.

## Customers

15 records are rejected because they are duplicate copies.

The final Silver customer table contains 700 unique trusted customers.

8 missing names are standardized to `Unknown`.

12 malformed emails are changed to null.

Those descriptive corrections do not prevent the customer from remaining usable as long as `customer_id` is valid.

## Products

4 duplicate copies are rejected.

The final Silver product table contains 80 trusted products.

Category values are standardized before Gold grouping.

## Orders

146 raw order records do not reach trusted Silver.

This includes duplicate copies and records affected by one or more of these issues:

- invalid order date
- unexpected order status
- customer not present in trusted customers

After exact duplicate removal, 91 unique order records fail structural or relationship validation.

The final Silver order table contains 4,409 trusted orders.

## Order Items

452 raw order-item records do not reach trusted Silver.

After duplicate removal, the main validation findings include:

- 92 non-positive quantities
- 61 non-positive unit prices
- 238 items whose order is not in trusted Silver orders
- 25 items whose product is not in trusted Silver products

These conditions can overlap on the same record, so issue counts should not be summed to calculate rejected rows.

The final Silver order-item table contains 10,696 trusted records.

## Payments

2,014 raw payment records do not reach trusted Silver.

30 of these are exact duplicate copies.

After exact duplicate removal, the major findings are:

- 13 amounts inconsistent with payment status
- 84 payments whose order is not in trusted Silver orders
- 1,893 payments dated before their trusted order date

Some payment rows have more than one reason, so reason counts overlap.

The final Silver payment table contains 2,058 trusted records.

The payment success rate is only 50.54%, making payments the largest source-quality concern.

## Traceability

Rejected records are not deleted silently.

They are written to:

`workspace.commerce_dataset.quarantine_records`

Each rejected record contains the original raw values as JSON and a validation reason.

## Result

The Silver layer is suitable as the trusted input to Gold because invalid and nonconforming records are excluded in a reproducible way and remain available for investigation in quarantine.
