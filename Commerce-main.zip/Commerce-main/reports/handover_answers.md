# Handover Questions

## 1. What was the most important data-quality problem you found?

The payment date relationship was the most important issue. A very large number of payment records are dated before the referenced order date. Under the current business rule, those payments cannot be treated as trusted payment activity and are quarantined.

This problem has a much larger effect than duplicate rows or the smaller number of invalid quantities/prices.

## 2. Which records did you quarantine and why?

The pipeline quarantines:

- extra exact duplicate copies
- conflicting business identifiers if different records remain for one ID after exact duplicate removal
- invalid identifiers
- invalid order dates
- unexpected order statuses
- orders whose customer is not trusted
- order items with non-positive quantity or unit price
- order items whose order or product is not trusted
- payments with invalid dates/status/methods
- payment amounts that are inconsistent with payment status
- payments whose order is not trusted
- payments dated before the order date

Every rejected record is stored with a validation reason and its original raw record in `quarantine_records`.

## 3. What makes a record eligible for Silver?

A Silver record must pass entity-level validation, duplicate/conflict handling and the relationship rules relevant to that entity.

Silver is not just cleaned formatting. It represents the trusted business entities that downstream Gold metrics are allowed to use.

## 4. How did you decide what belongs in Gold?

Gold contains outputs that directly answer Finance and Analytics questions rather than reusable entity cleaning.

That includes:

- finance reconciliation by order
- trusted revenue orders
- revenue by date/city
- product/category contribution
- customer/customer-type contribution
- reconciliation summary and largest differences
- data-quality source-to-Silver metrics

## 5. How did you calculate expected order value?

For each trusted order:

`expected_order_value = SUM(quantity * unit_price)`

Only trusted Silver order items are included.

The item-level value is stored as `line_total`.

## 6. How did you define trusted revenue?

Trusted revenue is the expected order value for orders that are:

- trusted Silver orders
- `completed`
- `MATCHED` in Finance reconciliation

All other reconciliation conditions contribute zero trusted revenue.

This is deliberately conservative.

## 7. Why can an order and its payment disagree?

Possible reasons include:

- underpayment
- overpayment
- failed payment
- missing payment
- refund activity
- invalid payment amount/status combination
- invalid payment timing
- invalid or missing order items changing the trusted commercial value
- source-system timing or integration errors

The supplied files contain examples of several of these conditions.

## 8. What join choices did you make and why?

The cleaning notebook uses left joins with existence flags when validating parent relationships. That allows the pipeline to keep the source record long enough to attach a specific quarantine reason when the parent is missing.

The exploration notebook uses left-anti joins to directly identify raw orphan references.

Gold reconciliation starts from trusted orders and left-joins expected item value and payment aggregates. Starting from orders ensures an order remains visible even when it has no usable items or payment.

Trusted product revenue uses inner joins after the order has already been proven eligible for trusted revenue, because product/category contribution should only include trusted items and trusted products attached to those eligible orders.

## 9. What did `explain()` show you about one of your pipelines?

Notebook 3 runs formatted `explain()` on the trusted product-line pipeline.

The exact physical plan should be read from the Databricks run because join strategy can change with runtime statistics.

Conceptually, the plan shows Spark building a pipeline from Delta scans through filters and joins before product/category aggregation. Some join or aggregation stages may require exchanges/shuffles.

The important connection to lazy evaluation is that defining the DataFrame transformations does not immediately execute the full pipeline. Spark builds and optimizes the plan, and an action such as `display()`, `count()` or a Delta write triggers execution.

## 10. What would you change if these files contained hundreds of millions of rows?

I would keep the same business rules but change the execution strategy:

- ingest incrementally instead of fully rereading files
- use Auto Loader or equivalent incremental ingestion
- use Delta change processing / `MERGE` for Silver
- avoid repeated full-table `count()` actions in the production job
- select only required columns early
- maintain table statistics
- use appropriate join strategies and broadcast only genuinely small dimensions
- use partitioning or liquid clustering based on actual access patterns
- compact small files and maintain Delta tables
- add orchestration, checkpoints, monitoring and data-quality alerts
- process new/changed partitions rather than overwriting every table

The current implementation prioritizes readability and explainability for the assignment while keeping the business logic production-oriented.
