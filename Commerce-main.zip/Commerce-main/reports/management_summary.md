# Management Summary

The raw Commerce exports should not be used directly for Finance reporting.

The source data contains duplicate records, invalid order dates, orphan relationships, invalid quantities/prices and a major payment-date problem.

After validation, the trusted Silver datasets contain:

- 700 customers
- 80 products
- 4,409 orders
- 10,696 order items
- 2,058 payments

The payment file is the biggest concern. Only about 50.54% of raw payment records reach trusted Silver under the current rule that a payment cannot occur before its order date.

Finance reconciliation across the 4,409 trusted orders produces:

- 1,634 matched orders
- 79 underpaid orders
- 49 overpaid orders
- 470 orders with no usable payment
- 427 refunded orders
- 1,750 non-standard orders

Trusted revenue is intentionally limited to orders that are both:

- `completed`
- `MATCHED`

That produces 1,203 trusted revenue orders with total trusted revenue of approximately **$1,549,918.12**.

The strongest trusted-revenue city is Prizren at approximately **$215,802.76**.

The strongest product category is Home at approximately **$334,580.32**.

Business customers contribute approximately **$629,193.03**, Retail customers approximately **$614,837.62**, and VIP customers approximately **$305,887.47**.

## Can Finance trust the resulting revenue number?

Finance can trust the **Gold trusted-revenue figure as a conservative, reproducible subset** because it is calculated only from validated entities, validated relationships, completed orders and matched trusted payments.

Finance should **not** treat that figure as the total possible revenue represented by the raw exports. A large share of payment rows are rejected because they predate their orders. That upstream issue must be understood before Finance can claim complete revenue coverage.

The highest-priority source-system improvement is to investigate why payment dates frequently occur before order dates and whether those records represent bad timestamps, generated test data, or a legitimate prepayment business process that has not yet been documented.
