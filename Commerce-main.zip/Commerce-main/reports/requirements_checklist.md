# Requirements Checklist

## Architecture

- [x] Bronze / Silver / Gold architecture implemented.
- [x] Architecture diagram included in `reports/architecture_diagram.md`.
- [x] Bronze preserves raw source values with traceability metadata.
- [x] `order_date` and `payment_date` remain strings in Bronze and are parsed in Silver.

## Engineering Requirements

- [x] Explicit Spark schemas are used for source ingestion.
- [x] Raw and trusted datasets are separated.
- [x] Business values are standardized through reproducible PySpark transformations.
- [x] Identifiers, required fields, numeric values, dates and relationships are validated.
- [x] Rejected records are preserved with validation reasons.
- [x] Silver outputs are persistent Delta tables.
- [x] Gold outputs are persistent Delta tables.
- [x] Source CSV files are not edited.
- [x] Final totals are calculated from data, not hardcoded in notebooks.
- [x] Pipeline logic uses PySpark DataFrame operations.

## Data Quality and Relationships

- [x] Duplicate business identifiers investigated.
- [x] Missing/malformed values investigated.
- [x] Customer -> order relationship validated.
- [x] Order -> order item relationship validated.
- [x] Product -> order item relationship validated.
- [x] Order -> payment relationship validated.
- [x] Invalid quantities and prices handled.
- [x] Invalid/malformed dates handled.
- [x] Unexpected status values handled.
- [x] Non-obvious business rules documented in README.

## Finance Reconciliation

- [x] Expected order value calculated from trusted order items.
- [x] Matched orders identified.
- [x] Underpaid orders identified.
- [x] Overpaid orders identified.
- [x] Orders with no usable payment identified.
- [x] Refund conditions identified.
- [x] Non-standard conditions identified.
- [x] Order and payment status considered before trusted revenue is assigned.
- [x] Largest reconciliation differences surfaced.

## Gold Outcomes

- [x] Trusted revenue output.
- [x] Revenue by date and city.
- [x] Revenue by product and category.
- [x] Revenue by customer and customer type.
- [x] Reconciliation counts.
- [x] Largest reconciliation differences.
- [x] Source-to-Silver quality percentages.

## Spark Execution Review

- [x] Meaningful pipeline inspected with formatted `explain()`.
- [x] README explains lazy evaluation and how to interpret the plan.

## Deliverables

- [x] Databricks notebooks for ingestion/exploration, validation/transformation and business outputs.
- [x] Quarantine output with reasons.
- [x] Finance reconciliation output.
- [x] Data-quality summary.
- [x] README with execution order, assumptions, business rules and engineering decisions.
- [x] Management summary explaining Finance trust.
- [x] Handover questions answered.
- [x] End-to-end order trace included in Notebook 3.

## Acceptance-Criteria Support

- [x] Pipeline reruns from the original source paths.
- [x] Raw files remain unchanged.
- [x] Layer responsibilities are separated.
- [x] Invalid records remain traceable.
- [x] Relationships are validated.
- [x] Reconciliation is reproducible and explainable.
- [x] Final metrics use trusted data.
- [x] Order `600002` can be followed source -> Bronze -> Silver/quarantine -> Gold.
- [x] Major transformations and business decisions are documented for live explanation.
